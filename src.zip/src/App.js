import logo from './logo.svg';
import './App.css';
import CsvReader from './CsvReader';

function App() {
  return (
    <div className="App">
      <CsvReader />
    </div>
  );
}

export default App;
